#pragma once

#include <Xinput.h>

class Input
{
private:
	static BYTE m_OldKeyState[256];
	static BYTE m_KeyState[256];

public:
	static void Init();
	static void Uninit();
	static void Update();

	static bool GetKeyPress( BYTE KeyCode );
	static bool GetKeyTrigger( BYTE KeyCode );
	static bool GetKeyState( BYTE KeyCode );

	// ���X�e�B�b�N
	static float GetLeftStickX();
	static float GetLeftStickY();

	// �E�X�e�B�b�N
	static float GetRightStickX();
	static float GetRightStickY();

	// ABXY
	static bool GetButtonA();
	static bool GetButtonB();
	static bool GetButtonX();
	static bool GetButtonY();

	static bool GetButtonLEFT_SHOULDER();
	static bool GetButtonRIGHT_SHOULDER();
	static bool GetButtonLEFT_THUMB();
	static bool GetButtonRIGHT_THUMB();
	static bool GetButtonSTART();
	static bool GetButtonBACK();

	// ���g���K�[
	static bool GetButtonLEFT_TRIGGER();

	// �E�g���K�[
	static bool GetButtonRIGHT_TRIGGER();

	// �\���L�[
	static bool GetButtonDPAD_UP();
	static bool GetButtonDPAD_DOWN();
	static bool GetButtonDPAD_LEFT();
	static bool GetButtonDPAD_RIGHT();

	static bool GetButtonALL();
};
