#pragma once
#include "scene.h"

class Result_Clear : public Scene
{
private:
	class Transition* m_Transition{};
	class Audio* c_se{};

public:
	void Init() override;
	void Update() override;
};