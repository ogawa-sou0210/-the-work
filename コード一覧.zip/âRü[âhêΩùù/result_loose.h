#pragma once

#include "scene.h"

class Result_Loose : public Scene
{
private:
	class Transition* m_Transition{};
	class Audio* l_se{};

public:
	void Init() override;
	void Update() override;
};