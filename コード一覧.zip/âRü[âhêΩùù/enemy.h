#pragma once
#include "gameObject.h"

using namespace DirectX::SimpleMath;

class Enemy : public GameObject
{
private:

	class Audio* e_SE_Shot{};

public:
	void Init() override;
};