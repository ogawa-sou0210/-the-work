#pragma once

#include "main.h"
#include "renderer.h"
#include "gameObject.h"

class Shot_gage_empty : public GameObject
{

private:
	float maxHP;
	float currentHP;

	ID3D11Buffer* m_VertexBuffer{};
	ID3D11ShaderResourceView* m_Texture{};

	int m_Count;

public:
	void Init();
	void Uninit();
	void Update();
	void Draw();
};