#include "main.h"
#include "manager.h"
#include "renderer.h"
#include "input.h"
#include "scene.h"
#include "modelRenderer.h"
#include "enemy.h"
#include "shader.h"
#include "count_time.h"
#include "player.h"
#include "audio.h"

void Enemy::Init()
{
    AddComponent<Shader>()->Load("shader\\unlitTextureVS.cso", "shader\\unlitTexturePS.cso");
	AddComponent<ModelRenderer>()->Load("asset\\model\\Enemy_Normal_Cube.obj");

    e_SE_Shot = AddComponent<Audio>();
    e_SE_Shot->Load("asset\\audio\\e_shot.wav");
}