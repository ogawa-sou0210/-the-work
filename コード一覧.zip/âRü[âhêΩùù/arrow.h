#pragma once
#include	<d3d11.h>
#include	<SimpleMath.h>
#include	"gameObject.h"

using namespace DirectX::SimpleMath;

class Arrow : public GameObject
{

private:

	DirectX::SimpleMath::Vector3	m_Target{};
	DirectX::SimpleMath::Matrix		m_ViewMatrix{};

	float m_RotationSpeed; // ��]���x (���W�A��/�b) //�ǉ�
	float m_RotationAngle; // ��]�p�x (���W�A��)

	ID3D11Buffer* m_VertexBuffer{};
	ID3D11ShaderResourceView* m_Texture{};

public:
	void Init();
	void Uninit();
	void Update();
	void Draw();
};