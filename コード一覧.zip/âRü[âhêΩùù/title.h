#pragma once

#include "scene.h"
#include "gameObject.h"

class Title : public Scene
{
private:
	class Transition* m_Transition{};
	class Audio* t_bgm{};
	class Audio* t_se{};

	ID3D11Buffer* m_VertexBuffer{};
	ID3D11ShaderResourceView* m_Texture{};

public:
	void Init();
	void Uninit();
	void Draw();
};