#include "modelRenderer.h"
#include "sky.h"
#include "shader.h"

void Sky::Init()
{
	AddComponent<Shader>()->Load("shader\\unlitTextureVS.cso", "shader\\unlitTexturePS.cso");
	AddComponent<ModelRenderer>()->Load("asset\\model\\sky.obj"); // �w�i���f��
}