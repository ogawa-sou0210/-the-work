#pragma once

#include "gameObject.h"

class Player : public GameObject
{

private:

	DirectX::SimpleMath::Vector3		m_Velocity{};
	class Audio*	m_SE{};
	class Audio*	m_BGM_main{};
	class Audio*	m_SE_Shot{};
	class Audio*	m_SE_Destroy{};

public:
	void Init() override;
	void Update() override;
};