#pragma once
#include "gameObject.h"

class Effect_Destroy : public GameObject
{
private:
	static ID3D11Buffer* m_VertexBuffer;
	static ID3D11ShaderResourceView* m_Texture;

	int m_Count;
	float m_Size; // �����̑傫��

public:
	static void Load();
	static void Unload();

	void Init() override;
	void Update() override;
	void Draw() override;

	void SetSize(float size)
	{
		m_Size = size;
	}
};