#pragma once
#include "scene.h"

class Explanation : public Scene
{
private:
	class Transition* m_Transition{};
	class Audio* e_se{};

public:
	void Init() override;
	void Update() override;
};