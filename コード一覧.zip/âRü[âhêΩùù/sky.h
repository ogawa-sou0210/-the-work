#pragma once
#include "gameObject.h"

class Sky : public GameObject
{

private:

public:
	void Init() override;
};