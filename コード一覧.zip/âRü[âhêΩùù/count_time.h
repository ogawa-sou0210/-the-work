#pragma once

#include "gameObject.h"




class Count_Time : public GameObject
{

private:
	ID3D11Buffer*				m_VertexBuffer{};
	ID3D11ShaderResourceView*	m_Texture{};

	int m_Count;


public:
	void Init();
	void Uninit();
	void Draw();
	void AddCount(int Count) { m_Count += Count; }

	// ���݂̃X�R�A��Ԃ��Q�b�^�[�֐�
	int Get_pHP() const {return m_Count;}
};