#include "main.h"
#include "input.h"

BYTE Input::m_OldKeyState[256];
BYTE Input::m_KeyState[256];

bool L_stick_check = false;     //	���X�e�B�b�N�̔���
bool R_stick_check = false;     //	�E

bool L_stick_deepCheck = false; //	

// A�{�^�������O�ɉ�����Ă��邩�ǂ����������t���O
bool aButtonPressed = false;

float Stick_Outline = 0.5f;     // �X�e�B�b�N�̓��͔���̊�l

void Input::Init()
{
	memset( m_OldKeyState, 0, 256 );
	memset( m_KeyState, 0, 256 );
}

void Input::Uninit()
{
}

void Input::Update()
{
	memcpy( m_OldKeyState, m_KeyState, 256 );

	GetKeyboardState( m_KeyState );

    // �R���g���[���[�̓���
    float leftStickX = Input::GetLeftStickX();  //��
    float leftStickY = Input::GetLeftStickY();
    float RightStickX = Input::GetRightStickX();//�E
    float RightStickY = Input::GetRightStickY();

    if (-Stick_Outline > leftStickY)  // L�X�e�B�b�N����`�F�b�N 
    {
        L_stick_check = true;
    }
    else if (leftStickY > Stick_Outline)
    {
        L_stick_check = true;
    }
    else if (-Stick_Outline > leftStickX)
    {
        L_stick_check = true;
    }
    else if (leftStickX > Stick_Outline)
    {
        L_stick_check = true;
    }
    else
    {
        L_stick_check = false;
    }

    if (-Stick_Outline > RightStickY)  // R�X�e�B�b�N����`�F�b�N 
    {
        R_stick_check = true;
    }
    else if (RightStickY > Stick_Outline)
    {
        R_stick_check = true;
    }
    else if (-Stick_Outline > RightStickX)
    {
        R_stick_check = true;
    }
    else if (RightStickX > Stick_Outline)
    {
        R_stick_check = true;
    }
    else
    {
        R_stick_check = false;
    }
    //-----------------------------------------------------------------------------

    float Stick_deepOutline = 0.85f;
    if (-Stick_deepOutline > leftStickY)  // L�X�e�B�b�N����`�F�b�N (�[)
    {
        L_stick_deepCheck = true;
    }
    else if (leftStickY > Stick_deepOutline)
    {
        L_stick_deepCheck = true;
    }
    else if (-Stick_deepOutline > leftStickX)
    {
        L_stick_deepCheck = true;
    }
    else if (leftStickX > Stick_deepOutline)
    {
        L_stick_deepCheck = true;
    }
    else
    {
        L_stick_deepCheck = false;
    }

    // A�{�^�������݉�����Ă��邩�m�F
    if (Input::GetButtonA()) 
    {
        aButtonPressed = true;
    }

    // A�{�^���������ꂽ�Ƃ��Ƀt���O�����Z�b�g
    if (Input::GetButtonA()) 
    {
        aButtonPressed = false;
    }
}

bool Input::GetKeyPress(BYTE KeyCode)
{
    return (m_KeyState[KeyCode] & 0x80) != 0;
}

bool Input::GetKeyTrigger(BYTE KeyCode)
{
	return ((m_KeyState[KeyCode] & 0x80) && !(m_OldKeyState[KeyCode] & 0x80));
}

bool Input::GetKeyState(BYTE KeyCode)
{
    return ((m_KeyState[KeyCode] & 0x80) && !(m_OldKeyState[KeyCode] & 0x80));
}

float Input::GetLeftStickX() 
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // ���X�e�B�b�N��X���̓��͂��擾
    return state.Gamepad.sThumbLX / static_cast<float>(SHRT_MAX);
}
float Input::GetLeftStickY() 
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // ���X�e�B�b�N��Y���̓��͂��擾
    return state.Gamepad.sThumbLY / static_cast<float>(SHRT_MAX);
}

float Input::GetRightStickX()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // �E�X�e�B�b�N��X���̓��͂��擾
    return state.Gamepad.sThumbRX / static_cast<float>(SHRT_MAX);
}
float Input::GetRightStickY()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);
    DWORD result = XInputGetState(0, &state);

    // �E�X�e�B�b�N��Y���̓��͂��擾
    return state.Gamepad.sThumbRY / static_cast<float>(SHRT_MAX);
}

bool Input::GetButtonA()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // A�{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_A) != 0;
}

bool Input::GetButtonB()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // A�{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_B) != 0;
}

bool Input::GetButtonX()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // A�{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_X) != 0;
}

bool Input::GetButtonY()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // A�{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_Y) != 0;
}

bool Input::GetButtonLEFT_SHOULDER()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // A�{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER) != 0;
}

bool Input::GetButtonRIGHT_SHOULDER()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // A�{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) != 0;
}

bool Input::GetButtonLEFT_THUMB()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // A�{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB) != 0;
}

bool Input::GetButtonRIGHT_THUMB()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // A�{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB) != 0;
}

bool Input::GetButtonSTART()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // A�{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_START) != 0;
}

bool Input::GetButtonBACK()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // A�{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_BACK) != 0;
}

bool Input::GetButtonLEFT_TRIGGER()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // ���g���K�[�̏�Ԃ��擾
    return (state.Gamepad.bLeftTrigger > XINPUT_GAMEPAD_TRIGGER_THRESHOLD);
}

bool Input::GetButtonRIGHT_TRIGGER()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // �E�g���K�[�̏�Ԃ��擾
    return (state.Gamepad.bRightTrigger > XINPUT_GAMEPAD_TRIGGER_THRESHOLD);
}

bool Input::GetButtonDPAD_UP()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // ��{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) != 0;
}

bool Input::GetButtonDPAD_DOWN()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // ���{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN) != 0;
}

bool Input::GetButtonDPAD_LEFT()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // ���{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) != 0;
}

bool Input::GetButtonDPAD_RIGHT()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // �E�{�^���̏�Ԃ��擾
    return (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) != 0;
}

bool Input::GetButtonALL()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    // �C�ӂ̃{�^����������Ă��邩�ǂ������擾
    return (state.Gamepad.wButtons & (
        XINPUT_GAMEPAD_A | XINPUT_GAMEPAD_B | XINPUT_GAMEPAD_X | XINPUT_GAMEPAD_Y |
        XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_RIGHT_SHOULDER |
        XINPUT_GAMEPAD_LEFT_THUMB | XINPUT_GAMEPAD_RIGHT_THUMB |
        XINPUT_GAMEPAD_START | XINPUT_GAMEPAD_BACK)) != 0;
}