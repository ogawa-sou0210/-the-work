#pragma once
#include	<functional>

void Invoke(std::function<void()> Function, int Time);